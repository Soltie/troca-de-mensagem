# Tung Tung Sahur — casa, floresta e Caçada Tum-Tum

Snapshot integrado de 18/10/2026. Comece por [INICIAR_AQUI.md](INICIAR_AQUI.md).

- História/Desafio: oito capítulos, casa, floresta densa com 26 objetivos, van e epílogo.
- Caçada Tum-Tum: 3–6 jogadores, vila, poderes, câmera sem RMB e progressão própria.
- Mobile, HUD, remaster, conforto, dados e rede autoritativa preservados.

Build única: `build/Sahur_INTEGRADO.rbxlx`, com fontes e rig embutidos.
Para enviar ao colega: o ZIP completo e [PROMPT_INTEGRACAO_COLEGA.md](PROMPT_INTEGRACAO_COLEGA.md).
Arquitetura de integração, proveniência e QA: [relatório atual](docs/INTEGRACAO_FLORESTA_TUMTUM.md).

```powershell
rokit install
lune run scripts/check
rojo build default.project.json --output build/Sahur_INTEGRADO.rbxlx
pwsh -File tools/audit_place.ps1 -PlacePath build/Sahur_INTEGRADO.rbxlx
```

Edite somente o src/ desta raiz. Para desenvolver com Script Sync, confirme as duas
raízes corretas no Studio. Para testar a build embutida, não precisa conectar sync.
Nunca rode rojo serve. Um Main por lado; remotes validados no servidor.

Studio/MCP, autenticação e acesso a assets precisam ser configurados no PC receptor.
Não há transferência de dados live, contas ou permissões no ZIP. Não publique ou faça
push sem pedido. Preserve as alterações do colega ao integrar.

Documentos antigos mantêm evidências históricas; datas, caminhos absolutos e Studio IDs
desses relatórios não descrevem o computador receptor. O [README original do template](docs/README_TEMPLATE_HISTORICO.md)
foi preservado para consulta.
