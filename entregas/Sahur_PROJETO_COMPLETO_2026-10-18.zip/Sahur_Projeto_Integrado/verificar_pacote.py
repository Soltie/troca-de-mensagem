import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/"MANIFEST.json").read_text(encoding="utf-8"))
errors=[]
for item in manifest["files"]:
 p=root/item["path"]
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest().upper()!=item["sha256"]: errors.append(item["path"])
expected={i["path"] for i in manifest["files"]}|{"MANIFEST.json"}
extra=[p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix() not in expected]
assert not errors and not extra, {"changed_or_missing":errors,"extra":extra}
print("PASS:",len(manifest["files"]),"files verified; build",manifest["buildSha256"])
