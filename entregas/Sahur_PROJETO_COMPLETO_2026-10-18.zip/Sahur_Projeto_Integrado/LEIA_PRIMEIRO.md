# Projeto completo integrado — 18/10/2026

Entregue esta pasta inteira ao agente, junto com o projeto receptor.
Cole PROMPT_INTEGRACAO_COLEGA.md no agente. As fontes atuais estão em projeto/src/.
Para jogar: projeto/build/Sahur_INTEGRADO.rbxlx no Roblox Studio.
Para desenvolver: abra projeto/ como raiz; leia AGENTS.md e INICIAR_AQUI.md.
Execute python verificar_pacote.py nesta raiz para conferir os arquivos.
O manifesto identifica HEAD, branch, hash da build e hashes individuais.

historico/Sahur.bundle é um histórico Git autocontido desta branch, sem config
de conta/remotes. Para inspecionar separadamente: git clone -b codex/forest-tumtum-export historico/Sahur.bundle referencia-sahur
O clone não contém a build ignorada pelo Git: ela está em projeto/build/.
O patch é para revisão, não aplicação automática sobre o trabalho do colega.

A floresta nova e a Caçada Tum-Tum estão reunidas. Outros jogos/branches,
credenciais, sessões de IA e DataStores publicados não fazem parte desta exportação.
Referências externas Roblox ainda dependem de acesso no destino. Não publique
ou sobrescreva o projeto receptor inteiro. Consulte o relatório atual em projeto/docs/.
