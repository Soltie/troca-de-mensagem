# Tungtung integrado ao experimento atual

Abra projeto/build/Tungtung_INTEGRADO.rbxl no Studio para testar a cópia completa.
Fontes: projeto/src/. Leia projeto/INTEGRACAO_ATUAL.md e projeto/docs/SHARED_INTEGRATION.md.
A build preserva o mundo/rig/settings atuais. Não substitua o experimento por uma build antiga.
O lugar 82955516040017 recebeu os oito arquivos por Script Sync; não houve publicação Roblox.
Apenas o integrador deste PC está conectado. Em outro PC, combine a reserva antes de conectar sync.
Coordenação e prompt do parceiro: https://github.com/Soltie/troca-de-mensagem

Rode rokit install; lune run scripts/check; lune run tools/build_shared; lune run tools/audit_shared.
A build específica usa integration-base/, não o antigo mundo do scripts/build.
O bundle contém histórico. Clone-o em uma pasta separada usando a branch indicada no manifesto.
Não inclui contas, credenciais, sessões privadas, acesso a assets externos ou DataStores live.
