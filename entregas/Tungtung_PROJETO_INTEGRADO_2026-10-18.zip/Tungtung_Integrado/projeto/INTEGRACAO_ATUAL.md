# Tungtung — integração com o experimento atual

Esta raiz usa como base os **250 scripts atuais** do experimento `tungtung`, PlaceId `82955516040017`, exportado em 18/10/2026. Preserva Midnight Hunt, filas/salas privadas e remaster de menus/loja. Não abra uma build antiga para substituir o destino.

## Abrir e reproduzir

- Abrir `build/Tungtung_INTEGRADO.rbxl` no Roblox Studio. É uma cópia completa com scripts embutidos; não conecte uma árvore antiga de Script Sync por cima.
- Fontes editáveis: `src/`. Histórico e decisões: `docs/SHARED_INTEGRATION.md`.
- Toolchain: `rokit install`; validar com `lune run scripts/check`.
- Build específica desta entrega: `lune run tools/build_shared`.
- Auditoria independente: `lune run tools/audit_shared`.

`integration-base/` conserva o backup nativo e o snapshot de fontes que o builder verifica antes de trabalhar. O builder modifica apenas chunks de propriedades Source. Não reserializa o mundo com o conversor: todas as demais propriedades, modelos, assets, Terrain e settings do backup permanecem byte a byte. A auditoria relê ambos os arquivos e compara os chunks, depois confere os 250 scripts.

`default.project.json`, Rojo e scripts/check continuam usados para sourcemap e análise. O comando genérico `scripts/build` monta o antigo mundo de desenvolvimento; **não é a build de entrega deste experimento**. Use tools/build_shared.

## Colaboração e instalação

Canal autorizado: https://github.com/Soltie/troca-de-mensagem. Leia mensagens/ e agentes/ antes de editar. Uma única frente deve conectar Script Sync. Fazer fetch antes de enviar documentação; sem force push, sem publicação Roblox ou alteração de dados live.

O pacote de referência anterior (floresta/remaster/Tum-Tum, commit 08f697c) continua disponível no canal, com os 11 arquivos da caçada antiga e seu histórico. Aqui se mantém o runtime Midnight Hunt atual; não se ativa uma segunda caçada concorrente. Schema8 mantém os dados `tumTum` antigos junto dos dados `pvp`, sem conversão de moeda ou concessão automática de prêmios.

Antes de instalar no lugar compartilhado, comparar novamente os hashes atuais com o snapshot e reconciliar qualquer mudança do parceiro. Uma build local testada não é confirmação de instalação/publicação no lugar compartilhado. O estado real está no relatório e no arquivo agentes/codex-integrador.md do canal.

Estado aplicado: integração conectada ao experimento 82955516040017 por Script Sync a partir de C:/Users/xpg/Documents/tungtung-integrado/src. As duas raízes e as 250 fontes foram verificadas. Somente este integrador deve escrever por sync. Sem publicação Roblox.
