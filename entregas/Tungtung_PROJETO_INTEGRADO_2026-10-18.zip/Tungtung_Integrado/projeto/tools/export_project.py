"""Exporta snapshot commitado, build auditada e historico portavel sem copiar .git/caches."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="build/Sahur_PROJETO_COMPLETO_2026-10-18.zip")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    if git(root, "status", "--porcelain"):
        raise SystemExit("Commit the intended source/docs before exporting; working tree is dirty.")
    head = git(root, "rev-parse", "HEAD")
    branch = git(root, "branch", "--show-current")
    if branch != "codex/forest-tumtum-export":
        raise SystemExit("Expected the integrated release branch.")
    output = (root / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise SystemExit(f"Refusing to replace an existing export: {output}")
    build = root / "build/Sahur_INTEGRADO.rbxlx"
    audit_file = root / "build/Sahur_INTEGRADO.audit.json"
    audit = json.loads(audit_file.read_text(encoding="utf-8-sig"))
    if audit["artifactSha256"].upper() != digest(build) or audit["mismatches"] or audit["extraScripts"]:
        raise SystemExit("Build audit mismatch.")
    for item in audit["sourceFiles"]:
        source = (root / "src" / item["file"]).read_text(encoding="utf-8")
        if hashlib.sha256(source.encode("utf-8")).hexdigest().upper() != item["sha256"].upper():
            raise SystemExit(f"Source changed after build audit: {item['file']}")
    receipt_file = root / "build/Sahur_INTEGRADO.receipt.json"
    receipt = json.loads(receipt_file.read_text(encoding="utf-8-sig"))
    if receipt["sha256"].upper() != digest(build):
        raise SystemExit("Release receipt belongs to different build bytes.")
    cache = root / ".cache"
    cache.mkdir(exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="sahur-export-", dir=cache))
    package = staging / "Sahur_Projeto_Integrado"
    project = package / "projeto"
    history = package / "historico"
    project.mkdir(parents=True)
    history.mkdir()
    source_zip = staging / "snapshot.zip"
    subprocess.run(["git", "-C", str(root), "archive", "--format=zip", "--output", str(source_zip), head], check=True)
    with zipfile.ZipFile(source_zip) as source:
        for member in source.infolist():
            path = Path(member.filename)
            if path.is_absolute() or ".." in path.parts:
                raise SystemExit("Unsafe source archive member.")
            if any(part in {".git", ".cache", "node_modules"} for part in path.parts):
                raise SystemExit(f"Unexpected private/generated source entry: {path}")
            if path.name == ".env" or path.name.startswith(".env.") or path.suffix in {".pem", ".key"}:
                raise SystemExit(f"Unexpected sensitive source entry: {path}")
        source.extractall(project)
    (project / "build").mkdir(exist_ok=True)
    for item in (build, audit_file, receipt_file):
        shutil.copy2(item, project / "build" / item.name)
    bundle = history / "Sahur.bundle"
    subprocess.run(["git", "-C", str(root), "bundle", "create", str(bundle), f"refs/heads/{branch}"], check=True)
    subprocess.run(["git", "-C", str(root), "bundle", "verify", str(bundle)], check=True, capture_output=True)
    patch = history / "alteracoes-desde-remaster.patch"
    with patch.open("wb") as target:
        subprocess.run(["git", "-C", str(root), "diff", "--binary", "19ace46", head], stdout=target, check=True)
    (history / "commits.txt").write_text(git(root, "log", "--oneline", branch) + "\n", encoding="utf-8")
    shutil.copy2(project / "PROMPT_INTEGRACAO_COLEGA.md", package / "PROMPT_INTEGRACAO_COLEGA.md")
    (package / "LEIA_PRIMEIRO.md").write_text(
        "# Projeto completo integrado — 18/10/2026\n\n"
        "Entregue esta pasta inteira ao agente, junto com o projeto receptor.\n"
        "Cole PROMPT_INTEGRACAO_COLEGA.md no agente. As fontes atuais estão em projeto/src/.\n"
        "Para jogar: projeto/build/Sahur_INTEGRADO.rbxlx no Roblox Studio.\n"
        "Para desenvolver: abra projeto/ como raiz; leia AGENTS.md e INICIAR_AQUI.md.\n"
        "Execute python verificar_pacote.py nesta raiz para conferir os arquivos.\n"
        "O manifesto identifica HEAD, branch, hash da build e hashes individuais.\n\n"
        "historico/Sahur.bundle é um histórico Git autocontido desta branch, sem config\n"
        "de conta/remotes. Para inspecionar separadamente: git clone -b codex/forest-tumtum-export "
        "historico/Sahur.bundle referencia-sahur\n"
        "O clone não contém a build ignorada pelo Git: ela está em projeto/build/.\n"
        "O patch é para revisão, não aplicação automática sobre o trabalho do colega.\n\n"
        "A floresta nova e a Caçada Tum-Tum estão reunidas. Outros jogos/branches,\n"
        "credenciais, sessões de IA e DataStores publicados não fazem parte desta exportação.\n"
        "Referências externas Roblox ainda dependem de acesso no destino. Não publique\n"
        "ou sobrescreva o projeto receptor inteiro. Consulte o relatório atual em projeto/docs/.\n",
        encoding="utf-8",
    )
    (package / "verificar_pacote.py").write_text(
        'import hashlib,json\nfrom pathlib import Path\nroot=Path(__file__).resolve().parent\n'
        'manifest=json.loads((root/"MANIFEST.json").read_text(encoding="utf-8"))\nerrors=[]\n'
        'for item in manifest["files"]:\n p=root/item["path"]\n'
        ' if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest().upper()!=item["sha256"]: errors.append(item["path"])\n'
        'expected={i["path"] for i in manifest["files"]}|{"MANIFEST.json"}\n'
        'extra=[p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and p.relative_to(root).as_posix() not in expected]\n'
        'assert not errors and not extra, {"changed_or_missing":errors,"extra":extra}\n'
        'print("PASS:",len(manifest["files"]),"files verified; build",manifest["buildSha256"])\n',
        encoding="utf-8",
    )
    files = [{"path": p.relative_to(package).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)}
             for p in sorted(package.rglob("*")) if p.is_file()]
    manifest = {"version": 1, "releaseDate": "2026-10-18", "branch": branch, "head": head,
                "build": "projeto/build/Sahur_INTEGRADO.rbxlx", "buildSha256": digest(build),
                "sourceCount": audit["sourceCount"], "validation": receipt, "files": files}
    (package / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    subprocess.run([__import__("sys").executable, str(package / "verificar_pacote.py")], check=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(package.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(staging).as_posix())
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None, "ZIP integrity failure"
    print(json.dumps({"zip": str(output), "sha256": digest(output), "bytes": output.stat().st_size,
                      "files": len(files) + 1, "staging": str(package), "head": head}, indent=2))


if __name__ == "__main__":
    main()
