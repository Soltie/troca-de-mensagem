"""Exporta a integração commitada com build nativa auditada e histórico recuperável."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile


def git(root: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    if git(root, "status", "--porcelain"):
        raise SystemExit("Commit the intended changes before export.")
    head = git(root, "rev-parse", "HEAD")
    branch = git(root, "branch", "--show-current")
    build = root / "build/Tungtung_INTEGRADO.rbxl"
    receipt = json.loads(Path(str(build) + ".receipt.json").read_text(encoding="utf-8"))
    audit = json.loads(Path(str(build) + ".audit.json").read_text(encoding="utf-8"))
    if digest(build) != receipt["outputSha256"] or audit["outputSha256"] != digest(build):
        raise SystemExit("Build receipt mismatch.")
    if not audit["allOtherChunksByteIdentical"] or audit["mismatches"] or audit["sourceCount"] != 250:
        raise SystemExit("Audit failed.")
    staging = Path(tempfile.mkdtemp(prefix="shared-export-", dir=root / ".cache"))
    package = staging / "Tungtung_Integrado"
    project = package / "projeto"
    history = package / "historico"
    project.mkdir(parents=True)
    history.mkdir()
    source_zip = staging / "source.zip"
    subprocess.run(["git", "-C", str(root), "archive", "--format=zip", "--output", str(source_zip), head], check=True)
    with zipfile.ZipFile(source_zip) as archive:
        for item in archive.infolist():
            p = Path(item.filename)
            if p.is_absolute() or ".." in p.parts or any(x in p.parts for x in (".git", ".cache")):
                raise SystemExit("Unexpected archive path.")
            if p.name == ".env" or p.name.startswith(".env.") or p.suffix in (".pem", ".key"):
                raise SystemExit("Unexpected secret file.")
        archive.extractall(project)
    (project / "build").mkdir(exist_ok=True)
    for path in (build, Path(str(build) + ".receipt.json"), Path(str(build) + ".audit.json")):
        shutil.copy2(path, project / "build" / path.name)
    bundle = history / "Tungtung.bundle"
    subprocess.run(["git", "-C", str(root), "bundle", "create", str(bundle), "refs/heads/" + branch], check=True)
    subprocess.run(["git", "-C", str(root), "bundle", "verify", str(bundle)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(root), "diff", "--binary", "--output=" + str(history / "integration-from-current-target.patch"), "d9bd32c", head], check=True)
    (package / "LEIA_PRIMEIRO.md").write_text(
        "# Tungtung integrado ao experimento atual\n\n"
        "Abra projeto/build/Tungtung_INTEGRADO.rbxl no Studio para testar a cópia completa.\n"
        "Fontes: projeto/src/. Leia projeto/INTEGRACAO_ATUAL.md e projeto/docs/SHARED_INTEGRATION.md.\n"
        "A build preserva o mundo/rig/settings atuais. Não substitua o experimento por uma build antiga.\n"
        "O lugar 82955516040017 recebeu os oito arquivos por Script Sync; não houve publicação Roblox.\n"
        "Apenas o integrador deste PC está conectado. Em outro PC, combine a reserva antes de conectar sync.\n"
        "Coordenação e prompt do parceiro: https://github.com/Soltie/troca-de-mensagem\n\n"
        "Rode rokit install; lune run scripts/check; lune run tools/build_shared; lune run tools/audit_shared.\n"
        "A build específica usa integration-base/, não o antigo mundo do scripts/build.\n"
        "O bundle contém histórico. Clone-o em uma pasta separada usando a branch indicada no manifesto.\n"
        "Não inclui contas, credenciais, sessões privadas, acesso a assets externos ou DataStores live.\n",
        encoding="utf-8",
    )
    files = [{"path": p.relative_to(package).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)}
             for p in sorted(package.rglob("*")) if p.is_file()]
    manifest = {"head": head, "branch": branch, "placeId": 82955516040017,
                "buildSha256": digest(build), "sourceCount": 250, "files": files}
    (package / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    output = root / "build/Tungtung_PROJETO_INTEGRADO_2026-10-18.zip"
    if output.exists():
        raise SystemExit("Refusing to replace an existing export.")
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(package.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(staging))
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
    report = {"head": head, "zipSha256": digest(output), "zipBytes": output.stat().st_size,
              "files": len(files) + 1, "buildSha256": digest(build), "staging": str(package)}
    output.with_suffix(".verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
