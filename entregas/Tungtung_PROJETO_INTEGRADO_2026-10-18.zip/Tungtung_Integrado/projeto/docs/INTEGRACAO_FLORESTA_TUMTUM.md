# Versão integrada para compartilhar — 18/10/2026

## Origem e decisão

A entrega TumTum_POLISH_FINAL vinha da branch `codex/tum-tum-hunt`, commit `ea8d040`,
baseada no remaster `19ace46` e na campanha consolidada `ce42900`.
As melhorias posteriores da floresta estavam em outro repositório local,
`tung-tung-sahur`, HEAD `7a7f4ca`; elas ainda não faziam parte da build Tum-Tum.

Integração nesta branch `codex/forest-tumtum-export`, sem substituir o src principal:

| Frente | Commit original | Commit incorporado | Resultado |
| --- | --- | --- | --- |
| Fundação da casa | ca0aec9 | cadfd02 | HouseEnvelope/HouseAccess e regressão de chão/porão |
| Floresta e epílogo | d2db940 | e87d3a8 | Densidade, 26 objetivos, pressão, rádio, atores/final |
| Recuperação do mouse na campanha | d975d86 | 59ea4f1 | Ponteiro após menu/cena; entrada documental adaptada |
| Tum-Tum e polish | 802ca30, 2975569, ea8d040 | ancestrais diretos | Preservados modos, economia e controles |

Áudio, Config e CampaignRuntime foram combinados por merge dos trechos. A única
divergência textual foi INICIAR_AQUI.md, reescrito para descrever a raiz integrada.
O controle do ponteiro recebeu um ajuste explícito: durante a caçada, a rotina geral
deixa a câmera TumTumCamera governar o mouse. Entrada de texto também libera o olhar.
Não houve rollback de schema: continua **7**, incluindo dados Tum-Tum e preferências.
Na inspeção do final integrado, os avisos de recompensa cobriam a cartela do epílogo.
O ajuste `4dd6b9e` faz os avisos aguardarem o fim da cena/cartela; o saldo e os pagamentos
não foram alterados. Captura final confirmou texto legível e holder de avisos invisível.

## Contratos para o agente receptor

| Sistema | Arquivos centrais | Preservar ao integrar |
| --- | --- | --- |
| Campanha/modos | CampaignRuntime, CoopSession, GameModes, HousePlan/Progression | História versus Standard, oito capítulos, transição casa/mata/lobby |
| Floresta | ForestCatalog, ForestPlan, ForestLayout, ForestBuilder | 8/9/9 objetivos, corredores/abrigos, pistas antes dos puzzles |
| Ameaça | ForestThreat, CreatureService, WorldService | Pressão só nos capítulos 6–8; visão/colisão autoritativas |
| Final | CinematicController, ForestCinema, ArmadilhoRig, StoryController | Dois atores temporários, cleanup/skip/cartela, EndingSeconds=34 |
| Fundação | HouseEnvelope, HouseAccess | Solo junto à fachada sem obstruir porão |
| Caçada | TumTumService/Round/Catalog/Progress/Arena/Controller | 3–6, servidor autoritativo, vila, poderes, XP/moedas, revanche/lobby |
| Câmera | CameraController, Camera/TumTumCamera | Um compositor, mouse livre sem RMB na caçada, menus liberam cursor |
| Apresentação | Audio/Fear/Flashlight/Lighting/ScreenFx/Cosmetic Controllers | Ramos da mata e da caçada, conforto, visibilidade |
| Dados/rede | Config/Types, PlayerDataSchema, Remotes, ServerNet | Schema7/migrações e campos existentes; validação/rate limit |
| Boot/assets | Main.server, Main.client, ReplicatedStorage/Assets | Uma inicialização por lado, rig/clipes existentes |

Todo o jogo deste snapshot está em `src/`, `places/`, `assets/` e configs/scripts da raiz.
O pacote inclui fontes editáveis, testes, ferramentas, build com scripts embutidos,
documentação/evidências, manifesto SHA-256 e bundle Git da branch entregue. O bundle
tem o histórico alcançável desta versão; não inclui branches de projetos alheios.
Não inclui sessões privadas, credenciais, caches, configuração de contas nem DataStores live.
Assets referenciados por ID continuam sujeitos ao acesso do projeto Roblox de destino.

`docs/evidence/forest-tumtum/source-index.json` inventaria os 236 arquivos Luau e o
modelo do rig, com hashes, requires/funções extraídos lexicalmente e IDs externos.
Esse índice facilita a comparação; não representa prova de execução de cada dependência.
`changes-from-remaster.txt` e o patch do pacote mostram as alterações desde `19ace46`.

## Build e validação

Build única: `build/Sahur_INTEGRADO.rbxlx`.
Rodar na raiz: `lune run scripts/check`; `rojo build default.project.json --output build/Sahur_INTEGRADO.rbxlx`.
Auditar: `pwsh -File tools/audit_place.ps1 -PlacePath build/Sahur_INTEGRADO.rbxlx`.
Toolchain fixada em `rokit.toml`; instalar com `rokit install`. Não usar `rojo serve`.

QA desta integração é registrado em `docs/evidence/forest-tumtum/` e no recibo da build.
Os 302 testes locais passaram. O runner no Studio passou em 315 testes, incluindo chão
da casa, navegação da mata e vila Tum-Tum. História em dupla passou 148 verificações;
Desafio em dupla passou 150, com oito capítulos, derrota/retry/resgate, van, epílogo,
retorno ao lobby, limpeza e nova votação. História precedeu somente o ajuste visual dos
avisos; Desafio foi executado sobre os bytes finais. Servidores sem erros do projeto.
O callback do editor do Desafio retornou sem payload; o resultado final success=true
e as 150 verificações foram recuperados do log do próprio servidor do teste.

A regressão Tum-Tum em três clientes passou 45 verificações nesta build: poderes,
captura/resgate, tambores, fuga, resultado/recompensa idempotente, revanche e voto ao lobby.
O olhar mudou 93,14° com os dois botões do mouse soltos via input virtual do engine;
a loja mudou Default → LockCenter ao abrir/fechar. Não foi uma medição com mouse físico.
Seis clientes e bloqueio com dois têm evidência na versão anterior do Tum-Tum;
essas duas configurações não foram repetidas nesta integração.
Mensagens de ChatScript/SetCore, CreatorType/CoreGui e UIBlox foram observadas nos clientes
e preservadas nos recibos; são caminhos internos Roblox, sem erro observado nos módulos
do jogo. Não se afirma console global completamente limpo. Runner e História precedem
somente a correção de toasts; o Desafio, os controles e o Tum-Tum usam os bytes finais.

Build SHA-256: `37F8ADC88CB78EFEFE2DB5CB6026188ADD605C95B8D55C19F97C5F68968EB128`.
Auditoria: 236 fontes em disco/embutidas, nenhuma ausente, divergente ou extra.
Todos os Plays desta frente encerrados; editor integrado em Edit. Outros projetos preservados.

Relatórios `FLORESTA_TERROR_ORIGEM.md`, `TUM_TUM_POLISH.md` e os demais relatórios antigos
descrevem snapshots anteriores. Seus caminhos, IDs e números de testes são históricos.
Use sempre o manifesto atual para identificar bytes e HEAD; o src recebido é a referência.

O pacote não instala nem autentica o Studio/MCP do colega e não conhece suas alterações.
O prompt orienta a comparar ambos os projetos antes de modificar qualquer um deles.
Não houve push, publicação nem migração de dados live. Testes locais com MockDataStore,
clientes do engine e preparo técnico não medem diversão/equilíbrio ou hardware físico.
