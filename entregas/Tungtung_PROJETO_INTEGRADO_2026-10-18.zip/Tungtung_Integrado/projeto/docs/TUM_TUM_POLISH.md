# Tum-Tum: revisão após o teste humano

17/10/2026. Branch `codex/tum-tum-hunt`, revisão sobre `1c926d0`.

**Estado: revisão local implementada e validada no Studio, sem publicação.**
Esta entrega substitui a prévia para os testes de jogo. A diversão e o equilíbrio
entre crianças/jogadores reais continuam sendo avaliação humana.

## O que mudou

- Arena refeita como **Vila do Tambor**: três casas atravessáveis por duas portas,
  praça, ruas conectadas, iluminação quente, tambores de madeira, cobertura e portão físico.
  São 483 peças; seis pontos de nascimento afastados das paredes.
- Câmera FPS explícita durante a caçada: movimento do mouse gira o olhar sem botão
  direito. Arraste e analógico direito também têm entrada própria. Menu pausa o olhar;
  saída da rodada restaura câmera, rotação do avatar e cursor.
- Caçador tem porrete em primeira pessoa, ataque no clique esquerdo, animação de golpe
  imediata, corrida ajustada à velocidade e pés posicionados pelo piso. A aparência
  padrão preserva a madeira do rig; susto usa o rosto do personagem em viewport.
- Contagem inicial de 2 s, preparação de 6 s, caça de 2 min 15 s, resultado de 4 s e
  revanche automática com novo sorteio sem repetir imediatamente o último caçador.
  R registra voto para lobby ao fim da rodada; maioria dos participantes volta ao menu.
- HUD menor, mira, indicação do tambor mais próximo, interação sem atravessar paredes
  e retirada de tambores já acesos da seleção.
- Lanterna dos sobreviventes corrigida para usar o estado Tum-Tum; iluminação, medo,
  música e batimento acompanham a arena e o caçador real.
- Visibilidade revisada após captura no engine: luz ambiente e luminárias mais legíveis,
  placas das casas em SurfaceGui e títulos cosméticos retirados da ação.

Economia e progressão permanecem as da entrega anterior. Outras campanhas e checkout
principal foram preservados; não houve publicação, push nem conexão ao Script Sync antigo.

## Evidência disponível

- `lune run scripts/check`: **ALL GREEN**, 298 testes, zero falhas, 7 specs dependentes
  do engine puladas no Lune.
- `lune run tools/test_tumtum_geometry`: executa o builder real no Lune; seis pontos
  livres, 18 rotas estáticas aos tambores e passagem pelo portão após abrir.
  Usa projeção conservadora das colisões em grade; não é o navmesh/física Roblox.
- `lune run tools/test_tumtum_camera`: executa o módulo real com input simulado;
  delta do mouse gira a câmera sem API de RMB, menu pausa/libera, fuga restaura estados.
  Não comprova foco da janela, input nativo ou integração com o PlayerModule.
- Auditoria da build: **230/230 fontes embutidas**, nenhuma divergência ou script extra.
- Runner no Studio: **310 passaram, zero falhas, zero specs puladas**, repetido na build
  final. `TumTumVillage` confere 18 rotas com PathfindingService, sem salto, e portão aberto.
- Multiplayer com 3 clientes: **45 verificações**. Com 6 clientes na build final:
  **66 verificações**. Captura, resgate, proteção, três poderes, canalização cancelável,
  três tambores, fuga de todos, vitória, recompensa idempotente, revanche com outro
  caçador, derrota por tempo, voto ao lobby e limpeza.
- Olhar no cliente do engine mudou **93,13° com RMB e LMB soltos**, via eventos do mouse
  virtual oficial. O delta relativo pode vir zerado nesse ambiente; a câmera agora
  também processa eventos de posição. Mouse físico e celular físico não foram medidos.
- W por 0,9 s deslocou o personagem **10,58 studs**. Clique esquerdo normal capturou
  alvo visível a 5 studs, com resposta `Pegou!`. Teleporte preparou a proximidade;
  o golpe foi enviado pelo input normal. Susto/rosto, porrete, vila e HUD capturados.
- L abriu a loja com mouse `Default` e olhar pausado; L fechou e restaurou `LockCenter`.

O primeiro harness falhou porque sua pausa visual de 10 s ultrapassava a preparação
de 6 s e ele então encerrava a caça por engano. Corrigido no arquivo de teste;
os dois cenários completos seguintes passaram. Recibo inicial preservado como evidência.

## Ambiente e limites

A prévia inicialmente travou ao abrir o Studio, com 12 instâncias na máquina.
Após autorização explícita do usuário para fechar todas, elas foram encerradas e
a nova build abriu normalmente. A causa interna do travamento não foi diagnosticada.

Servidores dos cenários e runner final sem erros/warnings. Não houve erro observado
do código do jogo nos clientes. Houve mensagens internas do Roblox: ChatScript/SetCore
em 3 dos 6 clientes e em 1 dos 3 da revisão de controles, avisos UIBlox/FoundationProvider
e erro de profiling do plugin MaterialManager no editor. Logs foram preservados;
não se afirma console global totalmente limpo nem homologação de chat na publicação.

Persistência testada com MockDataStore. Áudio humano, equilíbrio, mouse/aparelhos físicos
e backend publicado ainda precisam de teste humano/live. Todos os Plays encerrados;
somente o editor próprio `4326d8d1-24e3-4616-ad83-658c3a879a26` ficou em Edit.

## Abrir e reproduzir

`C:/Users/xpg/Documents/roblox-teste/build/TumTum_POLISH_FINAL.rbxlx`

No Studio, **Server & Clients** com 3 a 6 clientes; no lobby, JOGAR → CAÇADA ENTRE AMIGOS.
Play solo continua bloqueado. Os scripts estão embutidos: não sincronizar o src antigo.

```powershell
Set-Location 'C:/Users/xpg/.codex/worktrees/tum-tum-hunt/roblox-teste'
lune run scripts/check
lune run tools/test_tumtum_geometry
lune run tools/test_tumtum_camera
rojo build default.project.json --output build/TumTum_POLISH_FINAL.rbxlx
./tools/audit_place.ps1 -PlacePath build/TumTum_POLISH_FINAL.rbxlx
```

SHA-256: `58BA8AE68C0F47CCF45603EBBA1EED4D2BB9D2AB1D2801E27EEB21363D91E8B8`.
Recibo e logs locais: `docs/evidence/tum-tum-polish/`.

![Vila na build final](evidence/tum-tum-polish/village-final.png)
![Caçador observado no engine](evidence/tum-tum-polish/creature-final.png)
![Rosto do susto](evidence/tum-tum-polish/scare-final.png)
