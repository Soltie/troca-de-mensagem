# Evidências — Caçada Tum-Tum

As fontes desta frente estão no worktree `tum-tum-hunt`, base `19ace46` (remaster integrado).

- `check.txt`: 298 testes locais, zero falhas, seis specs exclusivas do engine puladas pelo Lune; format, lint, sourcemap e tipos ALL GREEN.
- `source-audit.json`: 227/227 scripts embutidos iguais a src, sem extras, preset Realistic/Future preservado. SHA-256 final `463438C5500383A174A1E5ED35EEFEF99D684A1F184C3F85BDAECD83D9648442`.
- `three-clients-initial.json`: primeiro ciclo de 39 verificações.
- `three-clients-final.json`: 39 verificações com HUD/espectador final, zero erros e warnings do servidor; anterior somente ao ajuste que distribui os seis pontos de nascimento e à sua asserção de QA.
- `two-clients-gate.json`: dois clientes reais tentam votar Tum-Tum; cinco verificações confirmam bloqueio e lobby disponível, sem erros/warnings.

No QA de três clientes, consultas aos três clientes confirmaram HUD correto, modelo do caçador nos dois sobreviventes e zero erros de cliente fora do CoreGui. Capturas MCP `TumTum_live_runner` e `TumTum_live_hunter` foram inspecionadas: HUD de sobrevivente com 2/3 selos e retorno ao lobby com o cartão Tum-Tum no painel rolável. Esses IDs de captura são referências da conversa, não arquivos locais.

O teste usa clientes do Roblox e remotes reais. Teleporte de cenário e mudança de relógio são setup técnico: não medem perseguição humana, dificuldade, FPS sustentado ou aparelho físico. Perfis locais usam MockDataStore; persistência em servidor publicado não foi testada. Nenhum teste autoriza ou comprova publicação.

- `six-clients-final.json`: 60 verificações na lotação de seis, incluindo 15 pares de spawn separados, poderes, resgate, todos escapando, pagamento único, timeout e nova rodada. Servidor sem erros/warnings.
- `six-clients-ui.json`: todos os seis HUDs ativos; um cliente registrou erro interno Roblox `StarterScript:507: Invalid value for enum CreatorType`, sem erro em src. Os outros cinco não tinham erros. Não ocultamos esse ruído do engine no recibo.
- `studio-specs.txt`: runner completo, 309 passed, 0 failed, 0 skipped. Inclui as seis specs que o Lune não executa.
- `iphone-result.png`: resultado ao vivo em iPhone 17 Pro simulado (750x381, paisagem).

A última alteração após o teste de seis e o runner foi exclusivamente no TumTumController: arsenal em DisplayOrder 230, backdrop modal e ações horizontais abaixo do cabeçalho em celular paisagem. A inspeção do arsenal e do HUD foi repetida na build final; nenhuma regra de jogo/servidor mudou nessa correção visual.

- `arsenal-final.png`: build final, painel acima do menu com backdrop; aberto por clique real. Classe Corredor aceita pelo servidor pelo botão real e refletida no perfil.
- `iphone-hunter-layout-preview.png`: inspeção de layout por estado local de UI em Play solo, não uma rodada desbloqueada. iPhone 17 Pro, 750x381; cabeçalho em (35,8) 680x112, ações em (498,140) 240x52; botões 116x52, sem sobreposição. O jogo declara LandscapeSensor e não foi forçada orientação retrato.
- `release.json`: hash final, origem, testes e limitações.

Simulador restaurado ao padrão e Play parado na build final. As correções finais de UI foram feitas nos arquivos de src, reconstruídas e verificadas em uma nova instância; ajustes temporários de preview nunca foram usados como entrega de código.
