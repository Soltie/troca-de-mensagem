# Caçada Tum-Tum

17/10/2026. Implementação na branch desta frente, em
`C:/Users/xpg/.codex/worktrees/tum-tum-hunt/roblox-teste`, base `19ace46`
(remaster visual sobre as três frentes integradas). O checkout principal, as campanhas
História/Desafio e as builds anteriores foram preservados.

## Jogar

No lobby, abrir JOGAR e votar em **CAÇADA ENTRE AMIGOS**, abaixo das duas campanhas.
Requer **3 a 6 jogadores** no servidor e maioria absoluta dos integrantes.
Com menos de três, o cartão mostra MÍNIMO: 3 e o servidor também recusa.
Empate não inicia a partida; saída de jogador durante a contagem reavalia a maioria.

- Um jogador vira o Tum-Tum por sorteio no servidor. O caçador anterior fica fora do
  próximo sorteio quando continua na equipe. Os demais viram sobreviventes.
- **18 segundos de esconderijo**: sobreviventes exploram; caçador permanece parado.
- **3 minutos de caça**: ativar três selos dourados diferentes, permanecendo perto por
  três segundos; andar, afastar-se, perder visão ou ser capturado cancela a ação.
- Os selos são compartilhados. Quando todos estão ativos, usar a saída verde.
- **Primeira captura**: o jogador fica caído por 24 segundos. Outro sobrevivente pode
  resgatar com uma ação de três segundos. Recebe seis segundos de proteção ao levantar.
- **Segunda captura** ou fim da janela de resgate: fora da rodada.
- O caçador vence se derrubar todos ou acabar o tempo sem nenhuma fuga. Os sobreviventes
  vencem se pelo menos um escapar; a rodada termina quando os demais se resolverem ou
  o relógio acabar. Quem foge recebe bônus individual.
- Resultado por 12 segundos, depois todos voltam ao lobby com votos limpos.
  Entradas tardias esperam a próxima rodada. Saída do caçador encerra sem recompensas.

A arena é separada da casa e da floresta: pátio, divisórias em L, caixas baixas e circuitos
com duas saídas para quebrar a visão. Spawn distribuído; caçador no centro. Os selos emitem
luz e têm identificação no mundo. A geometria é criada no servidor e destruída no retorno.

## Controles e poderes

WASD/direcional do Roblox para andar; mouse/arraste para olhar. **E / X** usa o alvo próximo
ou golpeia; **Q / Y** ativa o poder. Botões AÇÃO/PODER estão disponíveis na tela, inclusive
no toque. F controla a lanterna pelo sistema existente.

Todos os três estilos são gratuitos desde o primeiro acesso, escolhidos no botão
**PODERES, EVOLUÇÃO E APARÊNCIAS** do cartão no lobby. A escolha só vale na próxima rodada.

| Papel/estilo | Poder | Recarga |
| --- | --- | --- |
| Sobrevivente | Disparada por 3 s, velocidade 19 em vez de 12 | 20 s |
| Tum-Tum Rastreador | Eco revela por 4 s sobreviventes ativos em raio de 60 studs | 22 s |
| Tum-Tum Corredor | Disparada por 3 s, velocidade 21 em vez de 14 | 20 s |
| Tum-Tum Assombrador | Susto desacelera por 2 s quem está à vista em raio de 18 studs | 24 s |

Golpe tem alcance máximo 6,5 studs, cone frontal, linha de visão e recarga 1,8 s, inclusive
se errar. Distância e tempos são decididos no servidor. O modelo animado já existente do
Tung Tung acompanha o avatar do caçador para os outros jogadores. O susto usa som e cartela;
o efeito visual de captura respeita a preferência de flashes existente.

## Economia e evolução

Carteira própria **Moedas Tum-Tum**, XP, nível, vitórias, capturas, resgates e aparências
persistem no mesmo perfil com trava de sessão do projeto. Schema **7**, com migração de
versões antigas e saneamento de saldo/classe/itens corrompidos. Fichas, Créditos, XP geral,
campanhas, temporada e preferências anteriores são preservados.

Pagamento único por resultado; sem pagamento a espectadores, quem saiu, rodada cancelada
ou jogador sem ação válida e sem pelo menos 30 studs percorridos. Não há prêmio por bater
repetidamente em caído, repetir selo ou cancelar canalização.

| Evento | Moedas | XP |
| --- | --- | --- |
| Participação qualificada | 15 | 25 |
| Vitória da equipe | +35 | +40 |
| Selo concluído | +12 | +10 |
| Resgate concluído | +15, máximo 3 | +10 |
| Captura válida | +8, máximo 10 | +10 |
| Fuga individual | +20 | — |

O XP de ações é limitado a dez ações por rodada. Nível = `floor(sqrt(XP/100))+1`, máximo
50. O arsenal mostra o próximo marco. Classes e poder não ficam mais fortes por nível.

| Aparência | Preço | Nível mínimo |
| --- | --- | --- |
| Madeira | Grátis | 1 |
| Musgo | 180 moedas | 2 |
| Brasa | 420 moedas | 4 |
| Lua | 800 moedas | 6 |

Compra única com equipar gratuito depois. Apresentação muda a cor da criatura/olhos;
não muda alcance, velocidade, recarga nem tamanho do corpo físico. Não há Robux,
caixa aleatória, venda de moeda, perda de saldo por derrota ou bônus pago neste modo.

## Implementação e reprodução

`TumTumRound` é a máquina de estados pura; `TumTumCatalog` define conteúdo/balanço;
`TumTumProgress` calcula níveis, migração e compra; `TumTumArena` monta a geometria;
`TumTumService` integra perfil, validações, canais, movimento, ações e resultado;
`TumTumController` monta HUD/arsenal, poderes visuais e alvo de interação.

Um Service/Controller novo em cada bootstrap existente. Remote único `TumTumAction`
no registro central, passando por ServerNet com Guard para todos os argumentos e rate limit.
Runtime da campanha cede o controle enquanto a rodada Tum-Tum está ativa e retoma o lobby.
Nenhum código sincronizado foi editado no Studio.

```powershell
Set-Location 'C:/Users/xpg/.codex/worktrees/tum-tum-hunt/roblox-teste'
lune run scripts/check
rojo build default.project.json --output build/TumTum_CACADA.rbxlx
./tools/audit_place.ps1 -PlacePath build/TumTum_CACADA.rbxlx
```

Build local tem os scripts embutidos; abrir e testar sem conectar o Script Sync da pasta
principal antiga. Em Studio, usar Server & Clients com três clientes para formar a equipe.
Teste opt-in: `StudioTestService:ExecuteMultiplayerTestAsync(3,
{tumTumQA=true, modeMenuQA=true, players=3})`. `TumTumHarness` usa remotes dos clientes
e seleção normal do HUD; teleporte e ajuste de relógio são preparação técnica.

Os resultados finais e o hash da entrega constam no recibo e em `docs/evidence/tum-tum`.
O teste automatizado não mede diversão, dificuldade, audição humana ou celular físico.
Não houve push, publicação nem alteração de Creator Hub/monetização.

## Validação consolidada

298 testes locais e ALL GREEN; 309 testes do Studio; cenário de três clientes com 39 verificações; mínimo de dois bloqueado em cinco verificações; seis clientes em 60 verificações. Servidores multiplayer sem erros/warnings. Um dos seis clientes registrou erro interno do StarterScript do Roblox, preservado no recibo, sem erro do código do jogo. Capturas e inspeção real do arsenal/HUD, incluindo iPhone 17 Pro em paisagem.

O teste de seis e o runner precedem somente a correção visual final do arsenal e dos botões de paisagem. Regras e módulos do servidor são os mesmos. A renderização da correção foi conferida na build final.

## Entrega local

Build para abrir: `C:/Users/xpg/Documents/roblox-teste/build/TumTum_CACADA_FINAL.rbxlx`.
SHA-256: `463438C5500383A174A1E5ED35EEFEF99D684A1F184C3F85BDAECD83D9648442`. Código: `802ca30`, branch `codex/tum-tum-hunt`.
Recibo: `build/TumTum_CACADA_FINAL.receipt.json` no projeto principal.

No Studio, escolher **Test / Server & Clients** com **3** (ou até 6) clientes; no lobby,
JOGAR → rolar até CAÇADA ENTRE AMIGOS → maioria votar. Play solo mantém o modo bloqueado.
O arsenal abre no cartão mesmo solo para escolher classe e ver evolução. Os scripts já
estão na build: não ligar o Script Sync do checkout principal antigo a este arquivo.

Studio de QA `e4e9e020-45db-4c19-8d27-208b989ddf3c` deixado em Edit e simulador restaurado
a configuração padrão. Fontes dos demais worktrees e src principal preservadas.
