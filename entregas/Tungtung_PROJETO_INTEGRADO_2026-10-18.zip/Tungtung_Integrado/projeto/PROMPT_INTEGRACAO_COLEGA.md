# Prompt para o agente do colega

Cole o texto abaixo no agente e dê acesso à pasta extraída do ZIP e ao projeto atual do colega.
Não é preciso colar os arquivos de código na conversa.

~~~text
Integre a versão recebida do Tung Tung Sahur ao meu projeto Roblox atual, preservando as
alterações válidas dos dois projetos. O pacote recebido é Sahur_PROJETO_COMPLETO_2026-10-18.zip.
Trate o ZIP como uma versão completa de referência, sem substituir minha pasta inteira.
Faça a implementação e a validação local, não apenas um plano.

1. Extraia o pacote em pasta separada. Leia LEIA_PRIMEIRO.md e MANIFEST.json da raiz;
   depois projeto/AGENTS.md, projeto/INICIAR_AQUI.md e
   projeto/docs/INTEGRACAO_FLORESTA_TUMTUM.md. Confira os hashes do manifesto.
   Os caminhos C:/Users/xpg e IDs de Studio nos relatórios são históricos, não os deste PC.
   Não copie configurações de conta, permissões locais, conexões de sync ou remotes Git.

2. Antes de editar o projeto receptor, examine raiz Git, branch, HEAD, status, diffs,
   worktrees, AGENTS.md e reservas em LEIA_CLAUDE.md. Faça backup recuperável do estado
   atual, incluindo alterações não commitadas, e crie uma branch codex/integracao-sahur.
   Preserve arquivos/commits meus. Não use reset --hard, clean ou descarte de alterações.
   Identifique quais mudanças de cada lado já existem para evitar duplicação.

3. Use historico/Sahur.bundle para examinar o histórico entregue em um clone separado.
   Exemplo: git clone -b codex/forest-tumtum-export ../historico/Sahur.bundle sahur-referencia
   (adapte os caminhos). Não clone por cima da pasta existente. Compare os históricos
   com git merge-base antes de escolher merge/cherry-pick. Se não houver ancestral comum,
   integre por comparação de arquivos e contratos; não force --allow-unrelated-histories
   nem aplique o patch completo cegamente. O patch é material de revisão.
   O snapshot projeto/src deve corresponder ao HEAD indicado no manifesto.

4. Reúna todos os sistemas entregues, preservando os meus aprimoramentos compatíveis:
   - Casa e floresta em oito capítulos. História com sequência/cenas; Desafio com variação
     procedural e regras próprias. A fuga da casa no capítulo 5 leva à floresta; a vitória
     final depende da van no capítulo 8. Derrota/retry, resgate e retorno ao lobby funcionam.
   - Floresta nova: ForestLayout/ForestBuilder densos com acessos livres, 26 objetivos
     nos capítulos 6–8 (8/9/9), pistas/puzzles de rádio e autenticação, apagões,
     ForestThreat, patrulha/perseguição ajustadas, luz da criatura desligada na mata,
     novos props, ForestCinema e epílogo com Tung Tung e Crocodilo Armadilho.
   - Fundação da casa sem vãos, sem preencher o porão: HouseEnvelope/HouseAccess.
   - Remaster de materiais/luz, configurações de conforto/qualidade, HUD/guia,
     controles de toque, mochila, menus/loja, cinema/skip e feedback visual existentes.
   - Caçada Tum-Tum separada para 3–6 jogadores, sorteio sem repetir imediatamente
     o caçador, Vila do Tambor, FPS sem segurar RMB, porrete/golpe no clique, poderes,
     resgate/fuga, 6s de preparação, 135s de caça, resultado 4s e revanche automática,
     voto de lobby, XP/moedas/aparências próprios e persistência no perfil.

5. Resolva os pontos de integração de forma consciente:
   - Um Main de servidor e um Main de cliente; registre Services/Controllers uma vez.
   - Preserve Remotes.DEFINITIONS, ServerNet, Guard e rate limit de todos os argumentos.
   - Reconcilie CampaignRuntime/CoopSession/WorldService e o ciclo de TumTumService.
     Evite dois runtimes, duas câmeras ou listeners duplicados controlando a mesma fase.
   - CameraController recupera o ponteiro na campanha; durante Hide/Hunt Active/Downed
     deixa o controle com TumTumCamera. Menu, texto, loja e conforto devem liberar o mouse.
   - Mantenha os ramos de áudio/medo/lanterna/iluminação tanto da mata quanto do Tum-Tum.
     CampaignStatus=Waiting durante a caçada não pode desligar a lanterna do sobrevivente.
   - Não reverta schema 7 nem apague tumTum, house/preferences, progresso, moedas,
     temporada ou itens do perfil. Se meu projeto tiver schema mais recente, preserve-o
     e acrescente migração explícita. Preserve IDs de itens/receipts existentes.
   - Preserve os assets versionados de ReplicatedStorage/Assets, especialmente o rig
     TungTung.rbxm e seus clipes. Audite referências externas e permissões no destino.
     O ZIP não concede acesso a assets de terceiros ou transfere DataStores/contas.

6. Produza docs/RELATORIO_INTEGRACAO.md com uma tabela por sistema/arquivo:
   recebido, meu projeto, decisão final, conflitos resolvidos e evidência de teste.
   Prefira a união funcional; quando duas implementações de fato se contradisserem,
   preserve o comportamento existente válido e explique a decisão. Pergunte somente
   se houver uma decisão de produto impossível de inferir, sem bloquear o resto.

7. Instale/verifique a toolchain de rokit.toml. Edite src/ no disco. Rode
   lune run scripts/check até ALL GREEN, gere build/SAHUR_INTEGRADO_COLEGA.rbxlx com
   rojo build default.project.json e audite com tools/audit_place.ps1. Nada de rojo serve.
   Em outro PC pode ser necessário instalar Rokit/Studio/MCP e autenticar manualmente;
   não invente que está configurado. Use só um integrador de Script Sync por place.
   Para a build embutida, teste sem sincronizar uma árvore antiga por cima.

8. No MCP oficial, liste Studios e use studio_id em cada chamada. Faça Play no arquivo
   correto, runner ServerScriptService.Tests.Run, console e capturas, depois pare Play.
   Teste História e Desafio em dupla pelos oito capítulos, floresta/van/epílogo/lobby,
   derrota/retry/resgate/nova votação; teste Tum-Tum com 3 e 6, e bloqueio abaixo de 3.
   Use também input normal: andar, mouse com RMB solto, clique para golpear, loja e
   conforto abrindo/fechando. Teste ida e volta entre os modos para detectar vazamento
   de estado. Teleporte/IA congelada são setup técnico e não prova de balanceamento.
   Diferencie falhas do projeto de mensagens internas Roblox, guardando os logs.

9. Entregue uma build única, fontes integradas, commits locais pequenos, relatório,
   hashes e instruções para testar. Não publique, não faça push, não altere Creator Hub,
   compras/monetização ou dados live. Liste o que passou e o que ainda depende de
   aparelho físico, avaliação humana, acesso a assets ou persistência publicada.
~~~
