# Tung Tung Sahur — versão integrada

Esta raiz reúne casa e floresta de oito capítulos, melhorias de terror e epílogo,
remaster visual, mobile/cinema e Caçada Tum-Tum com evolução e economia próprias.
As fontes oficiais deste snapshot estão em src/ desta pasta.

Abra build/Sahur_INTEGRADO.rbxlx no Studio. Os scripts e o rig estão embutidos.
Para desenvolver: rokit install, lune run scripts/check e rojo build default.project.json.
Nunca conecte Script Sync a uma árvore antiga nem rode rojo serve.

Antes de integrar ao projeto do colega, leia PROMPT_INTEGRACAO_COLEGA.md e
docs/INTEGRACAO_FLORESTA_TUMTUM.md. Identifique a raiz e o snapshot localmente;
caminhos absolutos e Studio IDs de relatórios antigos são apenas históricos.

Não publique nem faça push sem pedido. Não sobrescreva o projeto receptor inteiro.
