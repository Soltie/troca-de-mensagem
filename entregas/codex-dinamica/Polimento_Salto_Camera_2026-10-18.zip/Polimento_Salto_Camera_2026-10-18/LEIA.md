# Polimento de salto e câmera — tungtung

Aplicado via MCP na place 82955516040017, sem Script Sync adicional ou publicação.
A iluminação escura aprovada e os modelos atuais foram preservados; a cópia local
incorporou as quatro fontes de iluminação que já estavam no destino.

O salto ganhou preparação, apoio dos braços, recolhimento assimétrico das pernas e
recuperação no pouso. A curva de deslocamento acelera e desacelera, com duração de
0,88 s. O servidor atualiza a passagem por quadro; os clientes interpolam a mesma
trajetória autorizada antes da câmera, evitando degraus visuais de rede. A direção
do corpo acompanha a passagem. Colisões, apoio, distância e rota continuam validados
no servidor; colisões e AutoRotate originais voltam ao terminar ou cancelar.

A animação é procedural sobre o rig real, com transições por fase, sem adicionar
IDs de animação que possam exigir permissão do proprietário. A câmera recebe um
movimento pequeno que respeita as opções de conforto.

Botões Modal agora só ficam ativos quando toda sua hierarquia está visível. Isso
evita a interferência de botões em painéis fechados na trava de primeira pessoa;
loja, guia, configurações e demais painéis abertos continuam liberando o cursor.
Referência: https://create.roblox.com/docs/reference/engine/classes/GuiButton/Modal

Validação: check337 ALL GREEN; runner Studio349; QA de dois jogadores77, incluindo
salto, janela, cooperação, bloqueio por parede, restauração e isolamento do PvP.
Sonda de UI: painel oculto com Modal=false; aberto com Modal=true e mouse Default;
fechado com Modal=false e mouse LockCenter; zero modais ativos em hierarquia oculta.
Movimento físico de mouse girou a câmera39,11 graus, com botão direito solto tanto
no evento de movimento quanto ao final. A sonda usou clique esquerdo para mover e
focar a viewport, sem arrastar nem manter botão pressionado.

A imagem POSE_INSPECAO_COM_LUZ_QA.jpg registra a pose pausada em43% do salto, com
uma luz temporária para inspecionar o avatar no porão escuro. Pausa, luz, câmera
lateral e auxiliares existiram apenas no Play de inspeção; nada disso foi salvo na
place. O QA funcional anterior usou duração real e confirmou a restauração.

Console mantém avisos preexistentes de asset81504106, EditableImage indisponível
com fallback e UIBlox do Roblox. Sem erro novo dos módulos alterados. Testes
encerrados e Studio devolvido ao modo de edição. Avaliação subjetiva do salto
continua aberta ao ajuste fino do humano em jogo.
